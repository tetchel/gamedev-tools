Tim Etchells Tools 2

How To Use

1. Go to Edit > Localizer > Language to add a language. Then, Edit Strings to add some localizable strings into the game.
Write your strings here, and the translation under the appropriate language column. For example, create a string called 
"helloworld" and give it a value of "Hello world".

2. Once you list some strings, you can add them to your game by editing the text field to have a "@" in front. So, to add
the translations of helloworld into our game, create a Text with value "@helloworld".

3. Run the game. The placeholder strings will be replaced by the translations for the selected language.

Source: https://github.com/tetchel/gamedev-tools
